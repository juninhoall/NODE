angular.module('starter')
.controller('settingsCtrl', function($scope, $ionicModal, $timeout) {


})
;
