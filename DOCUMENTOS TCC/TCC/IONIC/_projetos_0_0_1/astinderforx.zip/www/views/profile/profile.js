angular.module('starter')
.controller('profileCtrl', function($scope, $ionicModal, $timeout) {


})
;
