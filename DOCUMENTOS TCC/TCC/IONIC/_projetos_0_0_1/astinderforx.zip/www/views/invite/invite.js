angular.module('starter')
.controller('inviteCtrl', function($scope, $ionicModal, $timeout) {


})
;
